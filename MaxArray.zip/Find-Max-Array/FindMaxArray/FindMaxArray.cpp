// FindMaxArray.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
    int num[5] = { 3,6,10,20,11 };
    int max, pos;
    max = num[0];

    for (int i = 1; i < 5; i++) {
        if (num[i] > max) {
            max = num[i];
            pos = i;
        }
    }

    cout << "Largest element of an array is " << max << " and the index is " << pos;
}